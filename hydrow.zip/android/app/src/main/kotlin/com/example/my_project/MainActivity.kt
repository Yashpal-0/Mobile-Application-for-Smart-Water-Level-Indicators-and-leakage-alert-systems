package com.mycompany.hydrow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

// Export pages
export '/log_in_sign_up/log_in_sign_up_widget.dart' show LogInSignUpWidget;
export '/add_device_q_r_scan/add_device_q_r_scan_widget.dart'
    show AddDeviceQRScanWidget;
export '/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/cube_or_cy/cube_or_cy_widget.dart' show CubeOrCyWidget;
export '/add_device/add_device_widget.dart' show AddDeviceWidget;
export '/edit_device/edit_device_widget.dart' show EditDeviceWidget;
export '/edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export '/cuboidal_tank_edit/cuboidal_tank_edit_widget.dart'
    show CuboidalTankEditWidget;
export '/tank_summary/tank_summary_widget.dart' show TankSummaryWidget;
export '/individual_summary/individual_summary_widget.dart'
    show IndividualSummaryWidget;
export '/primary_tank/primary_tank_widget.dart' show PrimaryTankWidget;
export '/borewell_summary/borewell_summary_widget.dart'
    show BorewellSummaryWidget;
